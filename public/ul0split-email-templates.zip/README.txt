ul0.split email templates
=========================
templates/*.html  - 7 email-safe (tables + inline CSS) templates, {{handlebars}} placeholders
assets/*.png      - hero art + logo. Upload to https://ul0.site/email/assets/ (or change BASE url in the HTML)

Common placeholders: name, friend_name, creator_name, split_name, split_link, total, people_count, per_person,
amount, share_amount, paid_count, paid_percent (0-100 number), upi_id, days_pending, duration, collected,
splits_count, pending, week_range, fastest_payer, slowest_payer, biggest_split, cta_url, split_url,
confirm_url, pay_url, paid_url, dashboard_url, unsubscribe_url
Subjects are in each file's <title>.
