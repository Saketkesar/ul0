4 self-contained pages (logo + art embedded). Replace {{placeholders}} (email, friend_name, creator_name, split_name, amount, upi_id,
paid_time, paid_count, people_count, paid_percent, pay_url, split_url, dashboard_url) and wire the buttons ([data-to]) to your API.
